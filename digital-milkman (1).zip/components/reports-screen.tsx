"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { collectionDB, shiftDB } from "@/lib/db"
import type { Language } from "@/lib/i18n"
import { exportToCSV } from "@/lib/google-sheets"

interface ReportsScreenProps {
  language: Language
  onBack?: () => void
}

type FilterType = "date" | "farmer" | "shift" | "month"

export function ReportsScreen({ language, onBack }: ReportsScreenProps) {
  const [filterType, setFilterType] = useState<FilterType>("date")
  const [filterValue, setFilterValue] = useState("")
  const [selectedShift, setSelectedShift] = useState<"morning" | "evening" | "all">("all")

  const allCollections = useMemo(() => collectionDB.getAll(), [])
  const allShifts = useMemo(() => shiftDB.getAll(), [])

  const filteredCollections = useMemo(() => {
    let result = allCollections

    // Filter by shift
    if (selectedShift !== "all") {
      result = result.filter((c) => c.shift === selectedShift)
    }

    // Filter by type
    if (filterValue) {
      switch (filterType) {
        case "date":
          result = result.filter((c) => c.date === filterValue)
          break
        case "farmer":
          result = result.filter(
            (c) =>
              c.farmerCode.toLowerCase().includes(filterValue.toLowerCase()) ||
              c.farmerName.toLowerCase().includes(filterValue.toLowerCase()),
          )
          break
        case "month":
          result = result.filter((c) => c.date.startsWith(filterValue))
          break
      }
    }

    return result
  }, [allCollections, filterType, filterValue, selectedShift])

  const filteredShifts = useMemo(() => {
    let result = allShifts

    if (selectedShift !== "all") {
      result = result.filter((s) => s.shift === selectedShift)
    }

    if (filterValue && filterType === "date") {
      result = result.filter((s) => s.date === filterValue)
    }

    if (filterValue && filterType === "month") {
      result = result.filter((s) => s.date.startsWith(filterValue))
    }

    return result
  }, [allShifts, filterType, filterValue, selectedShift])

  const totals = useMemo(() => {
    return {
      farmers: new Set(filteredCollections.map((c) => c.farmerId)).size,
      quantity: filteredCollections.reduce((sum, c) => sum + c.quantity, 0),
      amount: filteredCollections.reduce((sum, c) => sum + c.amount, 0),
      collections: filteredCollections.length,
    }
  }, [filteredCollections])

  const handleExportCSV = () => {
    const data = filteredCollections.map((c) => ({
      Date: c.date,
      Shift: c.shift === "morning" ? "Morning" : "Evening",
      FarmerCode: c.farmerCode,
      FarmerName: c.farmerName,
      Quantity: c.quantity,
      Fat: c.fat,
      SNF: c.snf,
      Rate: c.rate,
      Amount: c.amount,
    }))

    exportToCSV(data, `milk-collection-${new Date().toISOString().split("T")[0]}.csv`)
  }

  const handleExportShifts = () => {
    const data = filteredShifts.map((s) => ({
      Date: s.date,
      Shift: s.shift === "morning" ? "Morning" : "Evening",
      "Total Farmers": s.totalFarmers,
      "Total Quantity": s.totalQuantity,
      "Total Amount": s.totalAmount,
      "Submitted At": s.submittedAt,
    }))

    exportToCSV(data, `shift-summary-${new Date().toISOString().split("T")[0]}.csv`)
  }

  return (
    <div className="space-y-6">
      {/* Filter Section */}
      <Card className="p-6 bg-card">
        <h2 className="text-2xl font-bold mb-4 text-foreground">{language === "hi" ? "रिपोर्ट" : "Reports"}</h2>

        <div className="space-y-4">
          {/* Shift Filter */}
          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">
              {language === "hi" ? "शिफ्ट" : "Shift"}
            </label>
            <div className="flex gap-2">
              <Button
                onClick={() => setSelectedShift("all")}
                className={`flex-1 ${
                  selectedShift === "all"
                    ? "bg-accent text-accent-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {language === "hi" ? "सभी" : "All"}
              </Button>
              <Button
                onClick={() => setSelectedShift("morning")}
                className={`flex-1 ${
                  selectedShift === "morning"
                    ? "bg-accent text-accent-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                🌄 {language === "hi" ? "सुबह" : "Morning"}
              </Button>
              <Button
                onClick={() => setSelectedShift("evening")}
                className={`flex-1 ${
                  selectedShift === "evening"
                    ? "bg-accent text-accent-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                🌆 {language === "hi" ? "शाम" : "Evening"}
              </Button>
            </div>
          </div>

          {/* Filter Type */}
          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">
              {language === "hi" ? "फ़िल्टर प्रकार" : "Filter Type"}
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {(["date", "farmer", "month"] as const).map((type) => (
                <Button
                  key={type}
                  onClick={() => {
                    setFilterType(type)
                    setFilterValue("")
                  }}
                  className={`${
                    filterType === type
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {type === "date" && (language === "hi" ? "तारीख" : "Date")}
                  {type === "farmer" && (language === "hi" ? "किसान" : "Farmer")}
                  {type === "month" && (language === "hi" ? "महीना" : "Month")}
                </Button>
              ))}
            </div>
          </div>

          {/* Filter Input */}
          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">
              {filterType === "date" && (language === "hi" ? "तारीख चुनें" : "Select Date")}
              {filterType === "farmer" && (language === "hi" ? "किसान खोजें" : "Search Farmer")}
              {filterType === "month" && (language === "hi" ? "महीना चुनें" : "Select Month")}
            </label>
            <Input
              type={filterType === "date" ? "date" : filterType === "month" ? "month" : "text"}
              value={filterValue}
              onChange={(e) => setFilterValue(e.target.value)}
              placeholder={filterType === "farmer" ? (language === "hi" ? "कोड या नाम" : "Code or name") : undefined}
              className="w-full"
            />
          </div>
        </div>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{language === "hi" ? "संग्रह" : "Collections"}</p>
          <p className="text-2xl font-bold text-accent">{totals.collections}</p>
        </Card>
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{language === "hi" ? "किसान" : "Farmers"}</p>
          <p className="text-2xl font-bold text-accent">{totals.farmers}</p>
        </Card>
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{language === "hi" ? "मात्रा" : "Quantity"}</p>
          <p className="text-2xl font-bold text-accent">{totals.quantity.toFixed(1)}L</p>
        </Card>
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{language === "hi" ? "राशि" : "Amount"}</p>
          <p className="text-2xl font-bold text-accent">₹{totals.amount.toFixed(0)}</p>
        </Card>
      </div>

      {/* Collections Table */}
      {filteredCollections.length > 0 && (
        <Card className="p-6 bg-card overflow-x-auto">
          <h3 className="text-lg font-semibold mb-4 text-foreground">
            {language === "hi" ? "संग्रह विवरण" : "Collection Details"}
          </h3>
          <div className="space-y-3">
            {filteredCollections.map((collection) => (
              <div key={collection.id} className="flex justify-between items-center p-3 bg-background rounded-lg">
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{collection.farmerName}</p>
                  <p className="text-xs text-muted-foreground">
                    {collection.date} • {collection.shift === "morning" ? "🌄" : "🌆"} • {collection.farmerCode}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">
                    {collection.quantity}L • F:{collection.fat}% • S:{collection.snf}%
                  </p>
                  <p className="font-bold text-accent">₹{collection.amount.toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Shift Summaries */}
      {filteredShifts.length > 0 && (
        <Card className="p-6 bg-card">
          <h3 className="text-lg font-semibold mb-4 text-foreground">
            {language === "hi" ? "शिफ्ट सारांश" : "Shift Summaries"}
          </h3>
          <div className="space-y-3">
            {filteredShifts.map((shift) => (
              <div key={shift.id} className="flex justify-between items-center p-3 bg-background rounded-lg">
                <div>
                  <p className="font-semibold text-foreground">
                    {shift.date} • {shift.shift === "morning" ? "🌄 Morning" : "🌆 Evening"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {language === "hi" ? "जमा किया गया" : "Submitted"}:{" "}
                    {new Date(shift.submittedAt).toLocaleTimeString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">
                    {shift.totalFarmers} {language === "hi" ? "किसान" : "farmers"} • {shift.totalQuantity.toFixed(1)}L
                  </p>
                  <p className="font-bold text-accent">₹{shift.totalAmount.toFixed(0)}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Export Buttons */}
      <div className="flex gap-2">
        <Button
          onClick={handleExportCSV}
          disabled={filteredCollections.length === 0}
          className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
        >
          {language === "hi" ? "CSV निर्यात करें" : "Export CSV"}
        </Button>
        <Button
          onClick={handleExportShifts}
          disabled={filteredShifts.length === 0}
          className="flex-1 bg-secondary hover:bg-secondary/90 text-secondary-foreground font-semibold"
        >
          {language === "hi" ? "शिफ्ट निर्यात करें" : "Export Shifts"}
        </Button>
      </div>

      {onBack && (
        <Button onClick={onBack} variant="outline" className="w-full bg-transparent">
          {language === "hi" ? "वापस" : "Back"}
        </Button>
      )}
    </div>
  )
}
