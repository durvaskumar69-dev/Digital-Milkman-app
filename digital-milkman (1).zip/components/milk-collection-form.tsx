"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { collectionDB, type Farmer, type MilkCollection } from "@/lib/db"
import { t, type Language } from "@/lib/i18n"
import { speak, stopSpeech } from "@/lib/voice"

interface MilkCollectionFormProps {
  farmer: Farmer
  shift: "morning" | "evening"
  language: Language
  onSuccess?: (collection: MilkCollection) => void
  onCancel?: () => void
}

export function MilkCollectionForm({ farmer, shift, language, onSuccess, onCancel }: MilkCollectionFormProps) {
  const [formData, setFormData] = useState({
    quantity: "",
    fat: "",
    snf: "",
    rate: "",
  })
  const [amount, setAmount] = useState(0)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(true)

  // Auto-calculate amount
  useEffect(() => {
    const qty = Number.parseFloat(formData.quantity) || 0
    const rt = Number.parseFloat(formData.rate) || 0
    setAmount(qty * rt)
  }, [formData.quantity, formData.rate])

  // Play voice prompt on mount
  useEffect(() => {
    if (voiceEnabled) {
      const prompt =
        language === "hi"
          ? "पहले पोर्ट में सैंपल लगाइए। किसान का नाम है " + farmer.name
          : "Place sample in first port. Farmer name is " + farmer.name

      setTimeout(() => speak(prompt, language), 500)
    }

    return () => stopSpeech()
  }, [farmer.name, language, voiceEnabled])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Validation
      if (!formData.quantity || Number.parseFloat(formData.quantity) <= 0) {
        setError(language === "hi" ? "मात्रा दर्ज करें" : "Enter quantity")
        setLoading(false)
        return
      }

      if (!formData.fat || Number.parseFloat(formData.fat) < 0 || Number.parseFloat(formData.fat) > 10) {
        setError(language === "hi" ? "वैध फैट % दर्ज करें (0-10)" : "Enter valid fat % (0-10)")
        setLoading(false)
        return
      }

      if (!formData.snf || Number.parseFloat(formData.snf) < 0 || Number.parseFloat(formData.snf) > 10) {
        setError(language === "hi" ? "वैध SNF % दर्ज करें (0-10)" : "Enter valid SNF % (0-10)")
        setLoading(false)
        return
      }

      if (!formData.rate || Number.parseFloat(formData.rate) <= 0) {
        setError(language === "hi" ? "दर दर्ज करें" : "Enter rate")
        setLoading(false)
        return
      }

      const collection = collectionDB.add({
        farmerId: farmer.id,
        farmerCode: farmer.code,
        farmerName: farmer.name,
        quantity: Number.parseFloat(formData.quantity),
        fat: Number.parseFloat(formData.fat),
        snf: Number.parseFloat(formData.snf),
        rate: Number.parseFloat(formData.rate),
        amount,
        shift,
        date: new Date().toISOString().split("T")[0],
        submitted: false,
      })

      // Play success voice
      if (voiceEnabled) {
        const successMsg =
          language === "hi"
            ? `${farmer.name} के लिए ${formData.quantity} लीटर दर्ज किया गया`
            : `Recorded ${formData.quantity} liters for ${farmer.name}`
        speak(successMsg, language)
      }

      setFormData({ quantity: "", fat: "", snf: "", rate: "" })
      onSuccess?.(collection)
    } catch (err) {
      setError(language === "hi" ? "त्रुटि हुई" : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="p-6 w-full max-w-2xl">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">{farmer.name}</h2>
          <p className="text-sm text-muted-foreground">
            {language === "hi" ? "कोड" : "Code"}: {farmer.code}
          </p>
          <p className="text-sm text-muted-foreground">
            {language === "hi" ? "शिफ्ट" : "Shift"}: {shift === "morning" ? "🌄 " : "🌆 "}
            {shift === "morning" ? (language === "hi" ? "सुबह" : "Morning") : language === "hi" ? "शाम" : "Evening"}
          </p>
        </div>
        <button
          onClick={() => setVoiceEnabled(!voiceEnabled)}
          className={`px-3 py-2 rounded-lg font-medium transition-colors ${
            voiceEnabled ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
          }`}
        >
          {voiceEnabled ? "🔊" : "🔇"}
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">{t("quantity", language)}</label>
            <Input
              type="number"
              name="quantity"
              value={formData.quantity}
              onChange={handleChange}
              placeholder="0.00"
              step="0.1"
              min="0"
              className="w-full"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">{t("fat", language)}</label>
            <Input
              type="number"
              name="fat"
              value={formData.fat}
              onChange={handleChange}
              placeholder="0.00"
              step="0.1"
              min="0"
              max="10"
              className="w-full"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">{t("snf", language)}</label>
            <Input
              type="number"
              name="snf"
              value={formData.snf}
              onChange={handleChange}
              placeholder="0.00"
              step="0.1"
              min="0"
              max="10"
              className="w-full"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">{t("rate", language)}</label>
            <Input
              type="number"
              name="rate"
              value={formData.rate}
              onChange={handleChange}
              placeholder="0.00"
              step="0.1"
              min="0"
              className="w-full"
              disabled={loading}
            />
          </div>
        </div>

        <div className="bg-accent/10 border border-accent rounded-lg p-4">
          <p className="text-sm text-muted-foreground">{language === "hi" ? "कुल राशि" : "Total Amount"}</p>
          <p className="text-3xl font-bold text-accent">₹{amount.toFixed(2)}</p>
        </div>

        {error && <div className="text-destructive text-sm font-medium">{error}</div>}

        <div className="flex gap-2 pt-4">
          <Button
            type="submit"
            disabled={loading}
            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
          >
            {loading ? (language === "hi" ? "सहेजा जा रहा है..." : "Saving...") : t("save", language)}
          </Button>
          {onCancel && (
            <Button
              type="button"
              onClick={onCancel}
              variant="outline"
              className="flex-1 bg-transparent"
              disabled={loading}
            >
              {t("cancel", language)}
            </Button>
          )}
        </div>
      </form>
    </Card>
  )
}
