"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import type { Farmer, MilkCollection } from "@/lib/db"
import type { Language } from "@/lib/i18n"
import { generatePaymentMessage, sendPaymentNotification, getNotificationConfig } from "@/lib/notifications"

interface PaymentNotificationProps {
  farmer: Farmer
  collection: MilkCollection
  language: Language
  onClose?: () => void
}

export function PaymentNotification({ farmer, collection, language, onClose }: PaymentNotificationProps) {
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState("")

  const config = getNotificationConfig()
  const message = generatePaymentMessage(collection, farmer, language)

  const handleSendNotification = async () => {
    setLoading(true)
    setError("")

    try {
      const results = await sendPaymentNotification(farmer, collection, language)

      if (results.whatsapp || results.sms) {
        setSent(true)
      } else {
        setError(language === "hi" ? "सूचना भेजने में विफल" : "Failed to send notification")
      }
    } catch (err) {
      setError(language === "hi" ? "त्रुटि हुई" : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  if (sent) {
    return (
      <Card className="p-6 bg-card text-center">
        <div className="text-4xl mb-3">✅</div>
        <p className="text-foreground font-semibold mb-4">{language === "hi" ? "सूचना भेजी गई" : "Notification Sent"}</p>
        <p className="text-sm text-muted-foreground mb-4">{farmer.mobile}</p>
        {onClose && (
          <Button onClick={onClose} className="bg-primary hover:bg-primary/90 text-primary-foreground">
            {language === "hi" ? "बंद करें" : "Close"}
          </Button>
        )}
      </Card>
    )
  }

  return (
    <Card className="p-6 bg-card">
      <h3 className="text-lg font-bold mb-4 text-foreground">
        {language === "hi" ? "भुगतान सूचना" : "Payment Notification"}
      </h3>

      <div className="bg-background p-4 rounded-lg mb-4 whitespace-pre-wrap text-sm text-foreground font-mono">
        {message}
      </div>

      <div className="space-y-2 mb-4">
        {config.enableWhatsApp && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="text-lg">💬</span>
            <span>{language === "hi" ? "WhatsApp भेजा जाएगा" : "Will send via WhatsApp"}</span>
          </div>
        )}
        {config.enableSMS && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="text-lg">📱</span>
            <span>{language === "hi" ? "SMS भेजा जाएगा" : "Will send via SMS"}</span>
          </div>
        )}
        {!config.enableWhatsApp && !config.enableSMS && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="text-lg">⚠️</span>
            <span>{language === "hi" ? "कोई सूचना विधि सक्षम नहीं है" : "No notification method enabled"}</span>
          </div>
        )}
      </div>

      {error && <div className="text-destructive text-sm font-medium mb-4">{error}</div>}

      <div className="flex gap-2">
        {(config.enableWhatsApp || config.enableSMS) && (
          <Button
            onClick={handleSendNotification}
            disabled={loading}
            className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
          >
            {loading ? (language === "hi" ? "भेजा जा रहा है..." : "Sending...") : language === "hi" ? "भेजें" : "Send"}
          </Button>
        )}
        {onClose && (
          <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent" disabled={loading}>
            {language === "hi" ? "बंद करें" : "Close"}
          </Button>
        )}
      </div>
    </Card>
  )
}
