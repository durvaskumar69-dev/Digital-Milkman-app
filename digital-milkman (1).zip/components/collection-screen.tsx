"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { farmerDB, collectionDB, type Farmer, type MilkCollection } from "@/lib/db"
import { t, type Language } from "@/lib/i18n"
import { FarmerCard } from "./farmer-card"
import { MilkCollectionForm } from "./milk-collection-form"
import { ShiftSummaryComponent } from "./shift-summary"

interface CollectionScreenProps {
  language: Language
  onBack?: () => void
}

type CollectionView = "select-shift" | "select-farmer" | "form" | "summary"

export function CollectionScreen({ language, onBack }: CollectionScreenProps) {
  const [view, setView] = useState<CollectionView>("select-shift")
  const [shift, setShift] = useState<"morning" | "evening">("morning")
  const [selectedFarmer, setSelectedFarmer] = useState<Farmer | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [collections, setCollections] = useState<MilkCollection[]>([])

  const farmers = useMemo(() => farmerDB.getAll(), [])

  const filteredFarmers = useMemo(() => {
    return farmers.filter(
      (farmer) =>
        farmer.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        farmer.name.toLowerCase().includes(searchTerm.toLowerCase()),
    )
  }, [farmers, searchTerm])

  const shiftCollections = useMemo(() => {
    const today = new Date().toISOString().split("T")[0]
    return collectionDB.getByShift(today, shift)
  }, [shift, collections])

  const handleShiftSelect = (selectedShift: "morning" | "evening") => {
    setShift(selectedShift)
    setView("select-farmer")
  }

  const handleFarmerSelect = (farmer: Farmer) => {
    setSelectedFarmer(farmer)
    setView("form")
  }

  const handleCollectionSuccess = (collection: MilkCollection) => {
    setCollections([...collections, collection])
    setSelectedFarmer(null)
    setSearchTerm("")
    setView("select-farmer")
  }

  const handleShowSummary = () => {
    setView("summary")
  }

  const handleBackToFarmers = () => {
    setView("select-farmer")
  }

  const handleBackToShift = () => {
    setView("select-shift")
  }

  const handleBackHome = () => {
    onBack?.()
  }

  if (view === "select-shift") {
    return (
      <div className="space-y-6">
        <Card className="p-8 bg-card text-center">
          <h2 className="text-2xl font-bold mb-6 text-foreground">{language === "hi" ? "शिफ्ट चुनें" : "Select Shift"}</h2>
          <div className="flex gap-4">
            <Button
              onClick={() => handleShiftSelect("morning")}
              className="flex-1 h-24 text-lg bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
            >
              🌄 {language === "hi" ? "सुबह" : "Morning"}
            </Button>
            <Button
              onClick={() => handleShiftSelect("evening")}
              className="flex-1 h-24 text-lg bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
            >
              🌆 {language === "hi" ? "शाम" : "Evening"}
            </Button>
          </div>
        </Card>
        {onBack && (
          <Button onClick={onBack} variant="outline" className="w-full bg-transparent">
            {language === "hi" ? "वापस" : "Back"}
          </Button>
        )}
      </div>
    )
  }

  if (view === "form" && selectedFarmer) {
    return (
      <div className="space-y-4">
        <MilkCollectionForm
          farmer={selectedFarmer}
          shift={shift}
          language={language}
          onSuccess={handleCollectionSuccess}
          onCancel={handleBackToFarmers}
        />
      </div>
    )
  }

  if (view === "summary") {
    return (
      <ShiftSummaryComponent
        date={new Date().toISOString().split("T")[0]}
        shift={shift}
        language={language}
        onSubmitSuccess={handleBackHome}
        onCancel={handleBackToFarmers}
      />
    )
  }

  return (
    <div className="space-y-6">
      {/* Shift Info */}
      <Card className="p-4 bg-accent/10 border border-accent">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-muted-foreground">{language === "hi" ? "वर्तमान शिफ्ट" : "Current Shift"}</p>
            <p className="text-lg font-bold text-foreground">
              {shift === "morning" ? "🌄 " : "🌆 "}
              {shift === "morning" ? (language === "hi" ? "सुबह" : "Morning") : language === "hi" ? "शाम" : "Evening"}
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">{language === "hi" ? "संग्रह" : "Collections"}</p>
            <p className="text-2xl font-bold text-accent">{shiftCollections.length}</p>
          </div>
        </div>
      </Card>

      {/* Search */}
      <Input
        type="text"
        placeholder={t("search", language)}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full"
      />

      {/* Farmer List */}
      <div>
        <h3 className="text-lg font-semibold mb-4 text-foreground">
          {language === "hi" ? "किसान चुनें" : "Select Farmer"}
        </h3>
        {filteredFarmers.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">{t("noData", language)}</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredFarmers.map((farmer) => (
              <FarmerCard key={farmer.id} farmer={farmer} language={language} onSelect={handleFarmerSelect} />
            ))}
          </div>
        )}
      </div>

      {/* Today's Collections */}
      {shiftCollections.length > 0 && (
        <Card className="p-6 bg-card">
          <h3 className="text-lg font-semibold mb-4 text-foreground">
            {language === "hi" ? "आज का संग्रह" : "Today's Collections"} ({shift === "morning" ? "🌄" : "🌆"})
          </h3>
          <div className="space-y-3 mb-4">
            {shiftCollections.map((collection) => (
              <div key={collection.id} className="flex justify-between items-center p-3 bg-background rounded-lg">
                <div>
                  <p className="font-semibold text-foreground">{collection.farmerName}</p>
                  <p className="text-sm text-muted-foreground">{collection.farmerCode}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-accent">₹{collection.amount.toFixed(2)}</p>
                  <p className="text-sm text-muted-foreground">{collection.quantity}L</p>
                </div>
              </div>
            ))}
          </div>
          <Button
            onClick={handleShowSummary}
            className="w-full h-12 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg"
          >
            {language === "hi" ? "शिफ्ट जमा करें" : "Submit Shift"}
          </Button>
        </Card>
      )}

      <div className="flex gap-2">
        <Button onClick={handleBackToShift} variant="outline" className="flex-1 bg-transparent">
          {language === "hi" ? "शिफ्ट बदलें" : "Change Shift"}
        </Button>
        {onBack && (
          <Button onClick={onBack} variant="outline" className="flex-1 bg-transparent">
            {language === "hi" ? "वापस" : "Back"}
          </Button>
        )}
      </div>
    </div>
  )
}
