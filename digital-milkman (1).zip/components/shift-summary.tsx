"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { shiftDB, collectionDB, type ShiftSummary } from "@/lib/db"
import { t, type Language } from "@/lib/i18n"
import { speak } from "@/lib/voice"

interface ShiftSummaryProps {
  date: string
  shift: "morning" | "evening"
  language: Language
  onSubmitSuccess?: (summary: ShiftSummary) => void
  onCancel?: () => void
}

export function ShiftSummaryComponent({ date, shift, language, onSubmitSuccess, onCancel }: ShiftSummaryProps) {
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const collections = collectionDB.getByShift(date, shift)
  const totalFarmers = collections.length
  const totalQuantity = collections.reduce((sum, c) => sum + c.quantity, 0)
  const totalAmount = collections.reduce((sum, c) => sum + c.amount, 0)

  const handleSubmit = () => {
    setLoading(true)

    try {
      const summary = shiftDB.submit(date, shift)

      if (summary) {
        setSubmitted(true)

        // Play success voice
        const successMsg =
          language === "hi"
            ? `शिफ्ट सफलतापूर्वक जमा किया गया। कुल ${totalFarmers} किसान, ${totalQuantity} लीटर, ${totalAmount} रुपये`
            : `Shift submitted successfully. Total ${totalFarmers} farmers, ${totalQuantity} liters, ${totalAmount} rupees`

        speak(successMsg, language)
        onSubmitSuccess?.(summary)
      }
    } catch (err) {
      console.error("Error submitting shift:", err)
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <Card className="p-8 bg-card text-center">
        <div className="text-5xl mb-4">✅</div>
        <h2 className="text-2xl font-bold mb-2 text-foreground">
          {language === "hi" ? "शिफ्ट जमा किया गया" : "Shift Submitted"}
        </h2>
        <p className="text-muted-foreground mb-6">
          {language === "hi" ? "आपका डेटा सुरक्षित रूप से सहेजा गया है" : "Your data has been saved securely"}
        </p>
        {onCancel && (
          <Button onClick={onCancel} className="bg-primary hover:bg-primary/90 text-primary-foreground">
            {language === "hi" ? "होम पर जाएं" : "Go to Home"}
          </Button>
        )}
      </Card>
    )
  }

  if (collections.length === 0) {
    return (
      <Card className="p-8 bg-card text-center">
        <p className="text-muted-foreground mb-4">
          {language === "hi" ? "इस शिफ्ट के लिए कोई डेटा नहीं है" : "No data for this shift"}
        </p>
        {onCancel && (
          <Button onClick={onCancel} variant="outline" className="bg-transparent">
            {language === "hi" ? "वापस" : "Back"}
          </Button>
        )}
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-card">
        <h2 className="text-2xl font-bold mb-6 text-foreground">
          {language === "hi" ? "शिफ्ट सारांश" : "Shift Summary"}
        </h2>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-background rounded-lg p-4 text-center">
            <p className="text-sm text-muted-foreground mb-1">{t("totalFarmers", language)}</p>
            <p className="text-3xl font-bold text-accent">{totalFarmers}</p>
          </div>
          <div className="bg-background rounded-lg p-4 text-center">
            <p className="text-sm text-muted-foreground mb-1">{t("totalQuantity", language)}</p>
            <p className="text-3xl font-bold text-accent">{totalQuantity.toFixed(1)}L</p>
          </div>
          <div className="bg-background rounded-lg p-4 text-center">
            <p className="text-sm text-muted-foreground mb-1">{t("totalAmount", language)}</p>
            <p className="text-3xl font-bold text-accent">₹{totalAmount.toFixed(0)}</p>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="font-semibold text-foreground">{language === "hi" ? "संग्रह विवरण" : "Collection Details"}</h3>
          {collections.map((collection) => (
            <div key={collection.id} className="flex justify-between items-center p-3 bg-background rounded-lg">
              <div>
                <p className="font-semibold text-foreground">{collection.farmerName}</p>
                <p className="text-xs text-muted-foreground">
                  {collection.farmerCode} • Fat: {collection.fat}% • SNF: {collection.snf}%
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-accent">₹{collection.amount.toFixed(2)}</p>
                <p className="text-sm text-muted-foreground">{collection.quantity}L</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <div className="flex gap-2">
        <Button
          onClick={handleSubmit}
          disabled={loading}
          className="flex-1 h-14 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg"
        >
          {loading ? (language === "hi" ? "जमा किया जा रहा है..." : "Submitting...") : t("submitShift", language)}
        </Button>
        {onCancel && (
          <Button
            onClick={onCancel}
            variant="outline"
            className="flex-1 h-14 bg-transparent font-semibold text-lg"
            disabled={loading}
          >
            {t("cancel", language)}
          </Button>
        )}
      </div>
    </div>
  )
}
