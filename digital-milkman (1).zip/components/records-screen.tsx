"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { collectionDB } from "@/lib/db"
import type { Language } from "@/lib/i18n"
import { t } from "@/lib/i18n"

interface RecordsScreenProps {
  language: Language
  onBack?: () => void
}

export function RecordsScreen({ language, onBack }: RecordsScreenProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])
  const [searchTerm, setSearchTerm] = useState("")

  const allCollections = useMemo(() => collectionDB.getAll(), [])

  const filteredCollections = useMemo(() => {
    let result = allCollections

    if (selectedDate) {
      result = result.filter((c) => c.date === selectedDate)
    }

    if (searchTerm) {
      result = result.filter(
        (c) =>
          c.farmerCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
          c.farmerName.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    return result.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
  }, [allCollections, selectedDate, searchTerm])

  const totals = useMemo(() => {
    return {
      quantity: filteredCollections.reduce((sum, c) => sum + c.quantity, 0),
      amount: filteredCollections.reduce((sum, c) => sum + c.amount, 0),
      avgFat:
        filteredCollections.length > 0
          ? filteredCollections.reduce((sum, c) => sum + c.fat, 0) / filteredCollections.length
          : 0,
      avgSnf:
        filteredCollections.length > 0
          ? filteredCollections.reduce((sum, c) => sum + c.snf, 0) / filteredCollections.length
          : 0,
    }
  }, [filteredCollections])

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-card">
        <h2 className="text-2xl font-bold mb-4 text-foreground">{t("viewRecords", language)}</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">{t("date", language)}</label>
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">{t("search", language)}</label>
            <Input
              type="text"
              placeholder={t("codeOrName", language)}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>
        </div>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{t("collections", language)}</p>
          <p className="text-2xl font-bold text-accent">{filteredCollections.length}</p>
        </Card>
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{t("totalQuantity", language)}</p>
          <p className="text-2xl font-bold text-accent">{totals.quantity.toFixed(1)}L</p>
        </Card>
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{language === "hi" ? "औसत फैट" : "Avg Fat"}</p>
          <p className="text-2xl font-bold text-accent">{totals.avgFat.toFixed(2)}%</p>
        </Card>
        <Card className="p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-1">{t("totalAmount", language)}</p>
          <p className="text-2xl font-bold text-accent">₹{totals.amount.toFixed(0)}</p>
        </Card>
      </div>

      {/* Records List */}
      {filteredCollections.length > 0 ? (
        <Card className="p-6 bg-card">
          <h3 className="text-lg font-semibold mb-4 text-foreground">{t("collectionDetails", language)}</h3>
          <div className="space-y-3">
            {filteredCollections.map((collection) => (
              <div
                key={collection.id}
                className="flex justify-between items-center p-4 bg-background rounded-lg hover:bg-background/80 transition-colors"
              >
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{collection.farmerName}</p>
                  <p className="text-xs text-muted-foreground">
                    {collection.farmerCode} • {collection.shift === "morning" ? "🌄" : "🌆"} •{" "}
                    {new Date(collection.timestamp).toLocaleTimeString(language === "hi" ? "hi-IN" : "en-IN")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">
                    {collection.quantity}L • F:{collection.fat}% • S:{collection.snf}%
                  </p>
                  <p className="font-bold text-accent">₹{collection.amount.toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      ) : (
        <Card className="p-8 bg-card text-center">
          <p className="text-muted-foreground">{t("noData", language)}</p>
        </Card>
      )}

      {onBack && (
        <Button onClick={onBack} variant="outline" className="w-full bg-transparent">
          {t("back", language)}
        </Button>
      )}
    </div>
  )
}
