"use client"

import { useState, useMemo } from "react"
import { type Farmer, farmerDB } from "@/lib/db"
import { FarmerCard } from "./farmer-card"
import { Input } from "@/components/ui/input"
import { type Language, t } from "@/lib/i18n"

interface FarmerListProps {
  language: Language
  onSelectFarmer?: (farmer: Farmer) => void
  showActions?: boolean
}

export function FarmerList({ language, onSelectFarmer, showActions = false }: FarmerListProps) {
  const [farmers, setFarmers] = useState<Farmer[]>(farmerDB.getAll())
  const [searchTerm, setSearchTerm] = useState("")

  const filteredFarmers = useMemo(() => {
    return farmers.filter(
      (farmer) =>
        farmer.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        farmer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        farmer.mobile.includes(searchTerm),
    )
  }, [farmers, searchTerm])

  const handleDelete = (farmerId: string) => {
    if (confirm(language === "hi" ? "क्या आप निश्चित हैं?" : "Are you sure?")) {
      farmerDB.delete(farmerId)
      setFarmers(farmerDB.getAll())
    }
  }

  return (
    <div className="space-y-4 w-full">
      <Input
        type="text"
        placeholder={t("search", language)}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full"
      />

      {filteredFarmers.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">{t("noData", language)}</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredFarmers.map((farmer) => (
            <FarmerCard
              key={farmer.id}
              farmer={farmer}
              language={language}
              onSelect={onSelectFarmer}
              onDelete={showActions ? handleDelete : undefined}
              showActions={showActions}
            />
          ))}
        </div>
      )}
    </div>
  )
}
