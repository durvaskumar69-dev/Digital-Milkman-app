"use client"

import type { Farmer } from "@/lib/db"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Language } from "@/lib/i18n"

interface FarmerCardProps {
  farmer: Farmer
  language: Language
  onSelect?: (farmer: Farmer) => void
  onDelete?: (farmerId: string) => void
  showActions?: boolean
}

export function FarmerCard({ farmer, language, onSelect, onDelete, showActions = false }: FarmerCardProps) {
  return (
    <Card className="p-4 bg-card hover:bg-card/80 transition-colors cursor-pointer">
      <div onClick={() => onSelect?.(farmer)} className="space-y-2">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-semibold text-muted-foreground">{language === "hi" ? "कोड" : "Code"}</p>
            <p className="text-lg font-bold text-foreground">{farmer.code}</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-semibold text-muted-foreground">{language === "hi" ? "नाम" : "Name"}</p>
            <p className="text-lg font-bold text-foreground">{farmer.name}</p>
          </div>
        </div>

        <div className="pt-2 border-t border-border">
          <p className="text-xs text-muted-foreground">{language === "hi" ? "मोबाइल" : "Mobile"}</p>
          <p className="text-sm font-medium text-foreground">{farmer.mobile}</p>
        </div>
      </div>

      {showActions && (
        <div className="flex gap-2 mt-4 pt-4 border-t border-border">
          <Button size="sm" variant="outline" className="flex-1 bg-transparent" onClick={() => onSelect?.(farmer)}>
            {language === "hi" ? "चुनें" : "Select"}
          </Button>
          {onDelete && (
            <Button size="sm" variant="destructive" className="flex-1" onClick={() => onDelete(farmer.id)}>
              {language === "hi" ? "हटाएं" : "Delete"}
            </Button>
          )}
        </div>
      )}
    </Card>
  )
}
