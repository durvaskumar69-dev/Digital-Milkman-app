"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { farmerDB, type Farmer } from "@/lib/db"
import { t, type Language } from "@/lib/i18n"

interface FarmerFormProps {
  language: Language
  onSuccess?: (farmer: Farmer) => void
  onCancel?: () => void
}

export function FarmerForm({ language, onSuccess, onCancel }: FarmerFormProps) {
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    mobile: "",
  })
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Validation
      if (!formData.code.trim()) {
        setError(language === "hi" ? "कोड आवश्यक है" : "Code is required")
        setLoading(false)
        return
      }

      if (!formData.name.trim()) {
        setError(language === "hi" ? "नाम आवश्यक है" : "Name is required")
        setLoading(false)
        return
      }

      if (!formData.mobile.trim() || formData.mobile.length < 10) {
        setError(language === "hi" ? "वैध मोबाइल नंबर दर्ज करें" : "Enter valid mobile number")
        setLoading(false)
        return
      }

      // Check if code already exists
      if (farmerDB.getByCode(formData.code)) {
        setError(language === "hi" ? "यह कोड पहले से मौजूद है" : "This code already exists")
        setLoading(false)
        return
      }

      const farmer = farmerDB.add({
        code: formData.code.toUpperCase(),
        name: formData.name,
        mobile: formData.mobile,
      })

      setFormData({ code: "", name: "", mobile: "" })
      onSuccess?.(farmer)
    } catch (err) {
      setError(language === "hi" ? "त्रुटि हुई" : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="p-6 w-full max-w-md">
      <h2 className="text-xl font-bold mb-4 text-foreground">{t("registerFarmer", language)}</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2 text-foreground">{t("farmerCode", language)}</label>
          <Input
            type="text"
            name="code"
            value={formData.code}
            onChange={handleChange}
            placeholder={language === "hi" ? "जैसे: F001" : "e.g., F001"}
            className="w-full"
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2 text-foreground">{t("farmerName", language)}</label>
          <Input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder={language === "hi" ? "किसान का नाम" : "Farmer name"}
            className="w-full"
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2 text-foreground">{t("mobile", language)}</label>
          <Input
            type="tel"
            name="mobile"
            value={formData.mobile}
            onChange={handleChange}
            placeholder="9876543210"
            className="w-full"
            disabled={loading}
            maxLength={10}
          />
        </div>

        {error && <div className="text-destructive text-sm font-medium">{error}</div>}

        <div className="flex gap-2 pt-4">
          <Button
            type="submit"
            disabled={loading}
            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            {loading ? (language === "hi" ? "सहेजा जा रहा है..." : "Saving...") : t("save", language)}
          </Button>
          {onCancel && (
            <Button
              type="button"
              onClick={onCancel}
              variant="outline"
              className="flex-1 bg-transparent"
              disabled={loading}
            >
              {t("cancel", language)}
            </Button>
          )}
        </div>
      </form>
    </Card>
  )
}
