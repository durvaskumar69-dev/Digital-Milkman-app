"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import type { Language } from "@/lib/i18n"
import { initNotifications, getNotificationConfig } from "@/lib/notifications"

interface NotificationSettingsProps {
  language: Language
  onClose?: () => void
}

export function NotificationSettings({ language, onClose }: NotificationSettingsProps) {
  const currentConfig = getNotificationConfig()
  const [config, setConfig] = useState(currentConfig)
  const [saved, setSaved] = useState(false)

  const handleToggle = (key: "enableWhatsApp" | "enableSMS" | "enableVoice") => {
    setConfig((prev) => ({ ...prev, [key]: !prev[key] }))
    setSaved(false)
  }

  const handleApiKeyChange = (key: "whatsappApiKey" | "smsApiKey", value: string) => {
    setConfig((prev) => ({ ...prev, [key]: value }))
    setSaved(false)
  }

  const handleSave = () => {
    initNotifications(config)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <Card className="p-6 bg-card max-w-md w-full">
      <h2 className="text-xl font-bold mb-4 text-foreground">
        {language === "hi" ? "सूचना सेटिंग्स" : "Notification Settings"}
      </h2>

      <div className="space-y-4">
        {/* Voice Toggle */}
        <div className="flex items-center justify-between p-3 bg-background rounded-lg">
          <div>
            <p className="font-medium text-foreground">🔊 {language === "hi" ? "आवाज़" : "Voice"}</p>
            <p className="text-xs text-muted-foreground">
              {language === "hi" ? "संग्रह के दौरान आवाज़ संकेत" : "Voice prompts during collection"}
            </p>
          </div>
          <button
            onClick={() => handleToggle("enableVoice")}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              config.enableVoice ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"
            }`}
          >
            {config.enableVoice ? (language === "hi" ? "चालू" : "On") : language === "hi" ? "बंद" : "Off"}
          </button>
        </div>

        {/* WhatsApp Toggle */}
        <div className="flex items-center justify-between p-3 bg-background rounded-lg">
          <div>
            <p className="font-medium text-foreground">💬 WhatsApp</p>
            <p className="text-xs text-muted-foreground">
              {language === "hi" ? "भुगतान सूचनाएं भेजें" : "Send payment notifications"}
            </p>
          </div>
          <button
            onClick={() => handleToggle("enableWhatsApp")}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              config.enableWhatsApp ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"
            }`}
          >
            {config.enableWhatsApp ? (language === "hi" ? "चालू" : "On") : language === "hi" ? "बंद" : "Off"}
          </button>
        </div>

        {config.enableWhatsApp && (
          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">
              {language === "hi" ? "WhatsApp API कुंजी" : "WhatsApp API Key"}
            </label>
            <Input
              type="password"
              value={config.whatsappApiKey || ""}
              onChange={(e) => handleApiKeyChange("whatsappApiKey", e.target.value)}
              placeholder={language === "hi" ? "API कुंजी दर्ज करें" : "Enter API key"}
              className="w-full"
            />
            <p className="text-xs text-muted-foreground mt-1">
              {language === "hi"
                ? "Twilio या WhatsApp Business API से प्राप्त करें"
                : "Get from Twilio or WhatsApp Business API"}
            </p>
          </div>
        )}

        {/* SMS Toggle */}
        <div className="flex items-center justify-between p-3 bg-background rounded-lg">
          <div>
            <p className="font-medium text-foreground">📱 SMS</p>
            <p className="text-xs text-muted-foreground">
              {language === "hi" ? "SMS सूचनाएं भेजें" : "Send SMS notifications"}
            </p>
          </div>
          <button
            onClick={() => handleToggle("enableSMS")}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              config.enableSMS ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"
            }`}
          >
            {config.enableSMS ? (language === "hi" ? "चालू" : "On") : language === "hi" ? "बंद" : "Off"}
          </button>
        </div>

        {config.enableSMS && (
          <div>
            <label className="block text-sm font-medium mb-2 text-foreground">
              {language === "hi" ? "SMS API कुंजी" : "SMS API Key"}
            </label>
            <Input
              type="password"
              value={config.smsApiKey || ""}
              onChange={(e) => handleApiKeyChange("smsApiKey", e.target.value)}
              placeholder={language === "hi" ? "API कुंजी दर्ज करें" : "Enter API key"}
              className="w-full"
            />
            <p className="text-xs text-muted-foreground mt-1">
              {language === "hi" ? "Twilio या AWS SNS से प्राप्त करें" : "Get from Twilio or AWS SNS"}
            </p>
          </div>
        )}
      </div>

      {saved && (
        <div className="mt-4 p-3 bg-accent/10 border border-accent rounded-lg text-sm text-accent font-medium">
          {language === "hi" ? "सेटिंग्स सहेजी गई" : "Settings saved"}
        </div>
      )}

      <div className="flex gap-2 mt-6">
        <Button
          onClick={handleSave}
          className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
        >
          {language === "hi" ? "सहेजें" : "Save"}
        </Button>
        {onClose && (
          <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
            {language === "hi" ? "बंद करें" : "Close"}
          </Button>
        )}
      </div>
    </Card>
  )
}
