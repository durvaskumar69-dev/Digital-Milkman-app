import type { Farmer, MilkCollection, ShiftSummary } from "./db"
import type { Language } from "./i18n"

export interface NotificationConfig {
  whatsappApiKey?: string
  smsApiKey?: string
  enableWhatsApp: boolean
  enableSMS: boolean
  enableVoice: boolean
}

let config: NotificationConfig = {
  enableWhatsApp: false,
  enableSMS: false,
  enableVoice: true,
}

export const initNotifications = (cfg: Partial<NotificationConfig>) => {
  config = { ...config, ...cfg }
}

export const getNotificationConfig = () => config

// Generate payment message
export const generatePaymentMessage = (collection: MilkCollection, farmer: Farmer, language: Language): string => {
  if (language === "hi") {
    return `नमस्ते ${farmer.name},\n\nआपके दूध का विवरण:\nमात्रा: ${collection.quantity}L\nफैट: ${collection.fat}%\nSNF: ${collection.snf}%\nदर: ₹${collection.rate}/L\n\nकुल राशि: ₹${collection.amount.toFixed(2)}\n\nधन्यवाद!`
  }

  return `Hello ${farmer.name},\n\nYour milk details:\nQuantity: ${collection.quantity}L\nFat: ${collection.fat}%\nSNF: ${collection.snf}%\nRate: ₹${collection.rate}/L\n\nTotal Amount: ₹${collection.amount.toFixed(2)}\n\nThank you!`
}

// Generate shift summary message
export const generateShiftSummaryMessage = (summary: ShiftSummary, language: Language): string => {
  if (language === "hi") {
    return `शिफ्ट सारांश (${summary.shift === "morning" ? "सुबह" : "शाम"})\n\nतारीख: ${summary.date}\nकुल किसान: ${summary.totalFarmers}\nकुल मात्रा: ${summary.totalQuantity.toFixed(1)}L\nकुल राशि: ₹${summary.totalAmount.toFixed(0)}\n\nशिफ्ट सफलतापूर्वक जमा किया गया।`
  }

  return `Shift Summary (${summary.shift === "morning" ? "Morning" : "Evening"})\n\nDate: ${summary.date}\nTotal Farmers: ${summary.totalFarmers}\nTotal Quantity: ${summary.totalQuantity.toFixed(1)}L\nTotal Amount: ₹${summary.totalAmount.toFixed(0)}\n\nShift submitted successfully.`
}

// Send WhatsApp message (requires backend integration)
export const sendWhatsAppMessage = async (
  phoneNumber: string,
  message: string,
): Promise<{ success: boolean; messageId?: string; error?: string }> => {
  if (!config.enableWhatsApp || !config.whatsappApiKey) {
    return { success: false, error: "WhatsApp not configured" }
  }

  try {
    // This would integrate with WhatsApp Business API or Twilio
    // For now, we'll log it and return success
    console.log("[WhatsApp] Sending to", phoneNumber, ":", message)

    // Example implementation with Twilio (would need backend route)
    // const response = await fetch('/api/send-whatsapp', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ phoneNumber, message })
    // })

    return { success: true, messageId: `msg_${Date.now()}` }
  } catch (error) {
    console.error("WhatsApp error:", error)
    return { success: false, error: String(error) }
  }
}

// Send SMS message (requires backend integration)
export const sendSMSMessage = async (
  phoneNumber: string,
  message: string,
): Promise<{ success: boolean; messageId?: string; error?: string }> => {
  if (!config.enableSMS || !config.smsApiKey) {
    return { success: false, error: "SMS not configured" }
  }

  try {
    // This would integrate with SMS provider like Twilio, AWS SNS, etc.
    console.log("[SMS] Sending to", phoneNumber, ":", message)

    // Example implementation with Twilio (would need backend route)
    // const response = await fetch('/api/send-sms', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ phoneNumber, message })
    // })

    return { success: true, messageId: `sms_${Date.now()}` }
  } catch (error) {
    console.error("SMS error:", error)
    return { success: false, error: String(error) }
  }
}

// Send notification via multiple channels
export const sendPaymentNotification = async (
  farmer: Farmer,
  collection: MilkCollection,
  language: Language,
): Promise<{ whatsapp?: boolean; sms?: boolean; voice?: boolean }> => {
  const message = generatePaymentMessage(collection, farmer, language)
  const results: { whatsapp?: boolean; sms?: boolean; voice?: boolean } = {}

  // Send WhatsApp
  if (config.enableWhatsApp) {
    const whatsappResult = await sendWhatsAppMessage(farmer.mobile, message)
    results.whatsapp = whatsappResult.success
  }

  // Send SMS
  if (config.enableSMS) {
    const smsResult = await sendSMSMessage(farmer.mobile, message)
    results.sms = smsResult.success
  }

  return results
}

// Send shift summary notification
export const sendShiftSummaryNotification = async (
  summary: ShiftSummary,
  language: Language,
): Promise<{ success: boolean }> => {
  const message = generateShiftSummaryMessage(summary, language)

  // Log for now - in production, this would send to admin/manager
  console.log("[Shift Summary Notification]", message)

  return { success: true }
}
