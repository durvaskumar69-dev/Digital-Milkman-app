export const speak = (text: string, language: "en" | "hi" = "en") => {
  if (typeof window === "undefined") return

  const utterance = new SpeechSynthesisUtterance(text)
  utterance.lang = language === "hi" ? "hi-IN" : "en-IN"
  utterance.rate = 0.9
  utterance.pitch = 1

  window.speechSynthesis.cancel()
  window.speechSynthesis.speak(utterance)
}

export const stopSpeech = () => {
  if (typeof window === "undefined") return
  window.speechSynthesis.cancel()
}
