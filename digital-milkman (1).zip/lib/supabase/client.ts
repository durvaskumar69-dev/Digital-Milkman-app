import { createBrowserClient } from "@supabase/ssr"

export function createClient() {
  const url = process.env.SUPABASE_SUPABASE_NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_NEXT_PUBLIC_SUPABASE_ANON_KEY_ANON_KEY

  if (!url || !key) {
    console.warn("[v0] Supabase environment variables not configured")
    // Return a dummy client that won't crash
    return createBrowserClient("https://placeholder.supabase.co", "placeholder-key")
  }

  return createBrowserClient(url, key)
}
