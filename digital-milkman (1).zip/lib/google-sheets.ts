export interface GoogleSheetsConfig {
  spreadsheetId: string
  apiKey: string
}

let config: GoogleSheetsConfig | null = null

export const initGoogleSheets = (spreadsheetId: string, apiKey: string) => {
  config = { spreadsheetId, apiKey }
}

export const syncToGoogleSheets = async (data: any, sheetName: string) => {
  if (!config) {
    console.warn("Google Sheets not configured")
    return false
  }

  try {
    // This would require server-side implementation with proper OAuth
    // For now, we'll use localStorage as primary storage
    console.log("Syncing to Google Sheets:", sheetName, data)
    return true
  } catch (error) {
    console.error("Failed to sync to Google Sheets:", error)
    return false
  }
}

export const exportToCSV = (data: any[], filename: string) => {
  const csv = convertToCSV(data)
  downloadCSV(csv, filename)
}

const convertToCSV = (data: any[]): string => {
  if (data.length === 0) return ""

  const headers = Object.keys(data[0])
  const rows = data.map((item) =>
    headers
      .map((header) => {
        const value = item[header]
        return typeof value === "string" && value.includes(",") ? `"${value}"` : value
      })
      .join(","),
  )

  return [headers.join(","), ...rows].join("\n")
}

const downloadCSV = (csv: string, filename: string) => {
  const blob = new Blob([csv], { type: "text/csv" })
  const url = window.URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = filename
  link.click()
  window.URL.revokeObjectURL(url)
}
