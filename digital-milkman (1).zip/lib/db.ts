export interface Farmer {
  id: string
  code: string
  name: string
  mobile: string
  createdAt: string
}

export interface MilkCollection {
  id: string
  farmerId: string
  farmerCode: string
  farmerName: string
  quantity: number
  fat: number
  snf: number
  rate: number
  amount: number
  shift: "morning" | "evening"
  date: string
  timestamp: string
  submitted: boolean
}

export interface ShiftSummary {
  id: string
  date: string
  shift: "morning" | "evening"
  totalFarmers: number
  totalQuantity: number
  totalAmount: number
  collections: MilkCollection[]
  submittedAt: string
}

// Local storage keys
const FARMERS_KEY = "dm_farmers"
const COLLECTIONS_KEY = "dm_collections"
const SHIFTS_KEY = "dm_shifts"

// Farmer operations
export const farmerDB = {
  getAll: (): Farmer[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(FARMERS_KEY)
    return data ? JSON.parse(data) : []
  },

  getById: (id: string): Farmer | null => {
    const farmers = farmerDB.getAll()
    return farmers.find((f) => f.id === id) || null
  },

  getByCode: (code: string): Farmer | null => {
    const farmers = farmerDB.getAll()
    return farmers.find((f) => f.code === code) || null
  },

  add: (farmer: Omit<Farmer, "id" | "createdAt">): Farmer => {
    const newFarmer: Farmer = {
      ...farmer,
      id: `farmer_${Date.now()}`,
      createdAt: new Date().toISOString(),
    }
    const farmers = farmerDB.getAll()
    farmers.push(newFarmer)
    localStorage.setItem(FARMERS_KEY, JSON.stringify(farmers))
    return newFarmer
  },

  update: (id: string, updates: Partial<Farmer>): Farmer | null => {
    const farmers = farmerDB.getAll()
    const index = farmers.findIndex((f) => f.id === id)
    if (index === -1) return null
    farmers[index] = { ...farmers[index], ...updates }
    localStorage.setItem(FARMERS_KEY, JSON.stringify(farmers))
    return farmers[index]
  },

  delete: (id: string): boolean => {
    const farmers = farmerDB.getAll()
    const filtered = farmers.filter((f) => f.id !== id)
    if (filtered.length === farmers.length) return false
    localStorage.setItem(FARMERS_KEY, JSON.stringify(filtered))
    return true
  },
}

// Milk collection operations
export const collectionDB = {
  getAll: (): MilkCollection[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(COLLECTIONS_KEY)
    return data ? JSON.parse(data) : []
  },

  getByDate: (date: string): MilkCollection[] => {
    const collections = collectionDB.getAll()
    return collections.filter((c) => c.date === date)
  },

  getByShift: (date: string, shift: "morning" | "evening"): MilkCollection[] => {
    const collections = collectionDB.getAll()
    return collections.filter((c) => c.date === date && c.shift === shift && !c.submitted)
  },

  add: (collection: Omit<MilkCollection, "id" | "timestamp">): MilkCollection => {
    const newCollection: MilkCollection = {
      ...collection,
      id: `collection_${Date.now()}`,
      timestamp: new Date().toISOString(),
    }
    const collections = collectionDB.getAll()
    collections.push(newCollection)
    localStorage.setItem(COLLECTIONS_KEY, JSON.stringify(collections))
    return newCollection
  },

  update: (id: string, updates: Partial<MilkCollection>): MilkCollection | null => {
    const collections = collectionDB.getAll()
    const index = collections.findIndex((c) => c.id === id)
    if (index === -1) return null
    collections[index] = { ...collections[index], ...updates }
    localStorage.setItem(COLLECTIONS_KEY, JSON.stringify(collections))
    return collections[index]
  },

  delete: (id: string): boolean => {
    const collections = collectionDB.getAll()
    const filtered = collections.filter((c) => c.id !== id)
    if (filtered.length === collections.length) return false
    localStorage.setItem(COLLECTIONS_KEY, JSON.stringify(filtered))
    return true
  },
}

// Shift operations
export const shiftDB = {
  getAll: (): ShiftSummary[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(SHIFTS_KEY)
    return data ? JSON.parse(data) : []
  },

  getByDateAndShift: (date: string, shift: "morning" | "evening"): ShiftSummary | null => {
    const shifts = shiftDB.getAll()
    return shifts.find((s) => s.date === date && s.shift === shift) || null
  },

  submit: (date: string, shift: "morning" | "evening"): ShiftSummary | null => {
    const collections = collectionDB.getByShift(date, shift)
    if (collections.length === 0) return null

    const summary: ShiftSummary = {
      id: `shift_${Date.now()}`,
      date,
      shift,
      totalFarmers: collections.length,
      totalQuantity: collections.reduce((sum, c) => sum + c.quantity, 0),
      totalAmount: collections.reduce((sum, c) => sum + c.amount, 0),
      collections,
      submittedAt: new Date().toISOString(),
    }

    // Mark collections as submitted
    collections.forEach((c) => {
      collectionDB.update(c.id, { submitted: true })
    })

    // Save shift summary
    const shifts = shiftDB.getAll()
    shifts.push(summary)
    localStorage.setItem(SHIFTS_KEY, JSON.stringify(shifts))

    return summary
  },
}
