-- Create dairy owner profiles table
CREATE TABLE IF NOT EXISTS public.dairy_owners (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create passkeys table for WebAuthn support
CREATE TABLE IF NOT EXISTS public.passkeys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  credential_id TEXT NOT NULL UNIQUE,
  public_key TEXT NOT NULL,
  sign_count INTEGER DEFAULT 0,
  transports TEXT[] DEFAULT ARRAY[]::TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  last_used TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.dairy_owners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.passkeys ENABLE ROW LEVEL SECURITY;

-- RLS Policies for dairy_owners
CREATE POLICY "dairy_owners_select_own"
  ON public.dairy_owners FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "dairy_owners_insert_own"
  ON public.dairy_owners FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "dairy_owners_update_own"
  ON public.dairy_owners FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "dairy_owners_delete_own"
  ON public.dairy_owners FOR DELETE
  USING (auth.uid() = id);

-- RLS Policies for passkeys
CREATE POLICY "passkeys_select_own"
  ON public.passkeys FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "passkeys_insert_own"
  ON public.passkeys FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "passkeys_delete_own"
  ON public.passkeys FOR DELETE
  USING (auth.uid() = user_id);

-- Create trigger to auto-create dairy_owner profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.dairy_owners (id, email, business_name)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data ->> 'business_name', 'My Dairy')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();
