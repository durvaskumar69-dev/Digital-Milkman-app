"use client"

import { createClient } from "@/lib/supabase/client"
import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import type { Language } from "@/lib/i18n"
import { Button } from "@/components/ui/button"
import { FarmerForm } from "@/components/farmer-form"
import { FarmerList } from "@/components/farmer-list"
import { CollectionScreen } from "@/components/collection-screen"
import { ReportsScreen } from "@/components/reports-screen"
import { RecordsScreen } from "@/components/records-screen"
import { NotificationSettings } from "@/components/notification-settings"
import { t } from "@/lib/i18n"
import Link from "next/link"

type Page = "home" | "register" | "collection" | "records" | "reports" | "settings"

export default function AppPage() {
  const [language, setLanguage] = useState<Language>("en")
  const [currentPage, setCurrentPage] = useState<Page>("home")
  const [mounted, setMounted] = useState(false)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const checkAuth = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
      }
      setUser(user)
      setMounted(true)
    }

    checkAuth()
  }, [])

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-primary text-primary-foreground sticky top-0 z-50 shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{t("appName", language)}</h1>
            <p className="text-sm opacity-90">{new Date().toLocaleDateString(language === "hi" ? "hi-IN" : "en-IN")}</p>
          </div>

          <div className="flex gap-2">
            <Link href="/dashboard/security">
              <button
                className="px-3 py-2 bg-primary-foreground text-primary rounded-lg font-medium hover:opacity-90 transition-opacity"
                title={t("settings", language)}
              >
                🔐
              </button>
            </Link>
            <button
              onClick={() => setLanguage(language === "en" ? "hi" : "en")}
              className="px-4 py-2 bg-primary-foreground text-primary rounded-lg font-medium hover:opacity-90 transition-opacity"
            >
              {language === "en" ? "हिंदी" : "English"}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8">
        {currentPage === "home" && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                onClick={() => setCurrentPage("collection")}
                className="h-24 text-lg bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
              >
                {t("startCollection", language)}
              </Button>
              <Button
                onClick={() => setCurrentPage("register")}
                className="h-24 text-lg bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              >
                {t("registerFarmer", language)}
              </Button>
              <Button
                onClick={() => setCurrentPage("records")}
                className="h-24 text-lg bg-secondary hover:bg-secondary/90 text-secondary-foreground font-semibold"
              >
                {t("viewRecords", language)}
              </Button>
              <Button
                onClick={() => setCurrentPage("reports")}
                className="h-24 text-lg bg-muted hover:bg-muted/90 text-muted-foreground font-semibold"
              >
                {t("reports", language)}
              </Button>
            </div>

            <div>
              <h2 className="text-2xl font-bold mb-4 text-foreground">{t("totalFarmers", language)}</h2>
              <FarmerList language={language} />
            </div>
          </div>
        )}

        {currentPage === "register" && (
          <div className="flex flex-col items-center">
            <FarmerForm
              language={language}
              onSuccess={() => setCurrentPage("home")}
              onCancel={() => setCurrentPage("home")}
            />
          </div>
        )}

        {currentPage === "collection" && <CollectionScreen language={language} onBack={() => setCurrentPage("home")} />}

        {currentPage === "records" && <RecordsScreen language={language} onBack={() => setCurrentPage("home")} />}

        {currentPage === "reports" && <ReportsScreen language={language} onBack={() => setCurrentPage("home")} />}

        {currentPage === "settings" && (
          <div className="flex flex-col items-center">
            <NotificationSettings language={language} onClose={() => setCurrentPage("home")} />
          </div>
        )}
      </main>

      {/* Footer Navigation */}
      <footer className="bg-card border-t border-border sticky bottom-0">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-around">
          <button
            onClick={() => setCurrentPage("home")}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
              currentPage === "home"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <span className="text-xl">🏠</span>
            <span className="text-xs font-medium">{t("home", language)}</span>
          </button>
          <button
            onClick={() => setCurrentPage("register")}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
              currentPage === "register"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <span className="text-xl">➕</span>
            <span className="text-xs font-medium">{t("addFarmer", language)}</span>
          </button>
          <button
            onClick={() => setCurrentPage("reports")}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
              currentPage === "reports"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <span className="text-xl">📊</span>
            <span className="text-xs font-medium">{t("reports", language)}</span>
          </button>
        </div>
      </footer>
    </div>
  )
}
