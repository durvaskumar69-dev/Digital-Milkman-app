"use client"

import { createClient } from "@/lib/supabase/client"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface Passkey {
  id: string
  credential_id: string
  created_at: string
  last_used: string | null
}

export default function SecurityPage() {
  const [passkeys, setPasskeys] = useState<Passkey[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    loadPasskeys()
  }, [])

  const loadPasskeys = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase
        .from("passkeys")
        .select("id, credential_id, created_at, last_used")
        .eq("user_id", user.id)

      if (error) throw error
      setPasskeys(data || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load passkeys")
    } finally {
      setIsLoading(false)
    }
  }

  const deletePasskey = async (passkeyId: string) => {
    try {
      const { error } = await supabase.from("passkeys").delete().eq("id", passkeyId)

      if (error) throw error
      setPasskeys(passkeys.filter((p) => p.id !== passkeyId))
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete passkey")
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground sticky top-0 z-50 shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Digital Milkman - Security</h1>
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              ← Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Security Settings</CardTitle>
            <CardDescription>Manage your passkeys and security options</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Passkeys</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Passkeys provide a secure, passwordless way to access your account. You can register multiple passkeys
                on different devices.
              </p>

              {isLoading ? (
                <p className="text-sm text-muted-foreground">Loading passkeys...</p>
              ) : error ? (
                <p className="text-sm text-red-500">{error}</p>
              ) : passkeys.length === 0 ? (
                <p className="text-sm text-muted-foreground mb-4">No passkeys registered yet.</p>
              ) : (
                <div className="space-y-2 mb-4">
                  {passkeys.map((passkey) => (
                    <div key={passkey.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Passkey</p>
                        <p className="text-xs text-muted-foreground">
                          Created: {new Date(passkey.created_at).toLocaleDateString()}
                        </p>
                        {passkey.last_used && (
                          <p className="text-xs text-muted-foreground">
                            Last used: {new Date(passkey.last_used).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      <Button variant="destructive" size="sm" onClick={() => deletePasskey(passkey.id)}>
                        Delete
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <Button className="w-full" disabled>
                🔑 Register Passkey (Coming Soon)
              </Button>
              <p className="text-xs text-muted-foreground mt-2">
                Passkey registration will be available soon. For now, use your email and password to log in.
              </p>
            </div>

            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold mb-4">Password</h3>
              <p className="text-sm text-muted-foreground mb-4">Change your password to keep your account secure.</p>
              <Button variant="outline" disabled>
                🔄 Change Password (Coming Soon)
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
