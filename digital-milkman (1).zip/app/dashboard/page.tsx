import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function DashboardPage() {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      redirect("/auth/login")
    }

    let profile = null
    try {
      const { data } = await supabase.from("dairy_owners").select("*").eq("id", user.id).single()
      profile = data
    } catch (error) {
      console.warn("[v0] Could not fetch profile:", error)
    }

    return (
      <div className="min-h-screen bg-background">
        <header className="bg-primary text-primary-foreground sticky top-0 z-50 shadow-md">
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Digital Milkman</h1>
              <p className="text-sm opacity-90">{profile?.business_name || "Dairy Management"}</p>
            </div>
            <div className="flex gap-2">
              <Link href="/dashboard/security">
                <Button variant="outline" size="sm">
                  🔐 Security
                </Button>
              </Link>
              <form
                action={async () => {
                  "use server"
                  const supabase = await createClient()
                  await supabase.auth.signOut()
                  redirect("/auth/login")
                }}
              >
                <Button type="submit" variant="outline" size="sm">
                  Logout
                </Button>
              </form>
            </div>
          </div>
        </header>

        <main className="max-w-6xl mx-auto px-4 py-8">
          <div className="bg-card border border-border rounded-lg p-6 mb-6">
            <h2 className="text-xl font-bold mb-2">Welcome, {profile?.business_name || "Dairy Owner"}!</h2>
            <p className="text-muted-foreground mb-4">Email: {user.email}</p>
            <p className="text-sm text-muted-foreground">
              Your dairy management dashboard is ready. Navigate to the app to start managing your farmers and milk
              collections.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link href="/app">
              <Button className="w-full h-24 text-lg">📊 Go to App</Button>
            </Link>
            <Link href="/dashboard/security">
              <Button variant="outline" className="w-full h-24 text-lg bg-transparent">
                🔐 Manage Security
              </Button>
            </Link>
          </div>
        </main>
      </div>
    )
  } catch (error) {
    console.warn("[v0] Dashboard access failed:", error)
    redirect("/auth/login")
  }
}
