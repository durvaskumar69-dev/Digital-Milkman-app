"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"
import type { Language } from "@/lib/i18n"
import { t } from "@/lib/i18n"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [language, setLanguage] = useState<Language>("en")
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })
      if (error) throw error
      router.push("/dashboard")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center p-6 md:p-10 bg-background">
      <div className="w-full max-w-sm">
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-3xl font-bold text-primary">{t("appName", language)}</h1>
            <button
              onClick={() => setLanguage(language === "en" ? "hi" : "en")}
              className="px-3 py-1 bg-secondary text-secondary-foreground rounded-lg text-sm font-medium hover:opacity-90"
            >
              {language === "en" ? "हिंदी" : "English"}
            </button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">{language === "en" ? "Login" : "लॉगिन"}</CardTitle>
              <CardDescription>
                {language === "en"
                  ? "Enter your email and password to access your dairy management dashboard"
                  : "अपने डेयरी प्रबंधन डैशबोर्ड तक पहुंचने के लिए अपना ईमेल और पासवर्ड दर्ज करें"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin}>
                <div className="flex flex-col gap-6">
                  <div className="grid gap-2">
                    <Label htmlFor="email">{language === "en" ? "Email" : "ईमेल"}</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="dairy@example.com"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="password">{language === "en" ? "Password" : "पासवर्ड"}</Label>
                    <Input
                      id="password"
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                  {error && <p className="text-sm text-red-500">{error}</p>}
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading
                      ? language === "en"
                        ? "Logging in..."
                        : "लॉगिन हो रहा है..."
                      : language === "en"
                        ? "Login"
                        : "लॉगिन"}
                  </Button>
                </div>
                <div className="mt-4 text-center text-sm">
                  {language === "en" ? "Don't have an account? " : "खाता नहीं है? "}
                  <Link href="/auth/sign-up" className="underline underline-offset-4 text-primary">
                    {language === "en" ? "Sign up" : "साइन अप करें"}
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
