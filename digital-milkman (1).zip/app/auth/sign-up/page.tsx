"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"
import type { Language } from "@/lib/i18n"
import { t } from "@/lib/i18n"

export default function SignUpPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [repeatPassword, setRepeatPassword] = useState("")
  const [businessName, setBusinessName] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [language, setLanguage] = useState<Language>("en")
  const router = useRouter()

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    if (password !== repeatPassword) {
      setError(language === "en" ? "Passwords do not match" : "पासवर्ड मेल नहीं खाते")
      setIsLoading(false)
      return
    }

    if (password.length < 8) {
      setError(language === "en" ? "Password must be at least 8 characters" : "पासवर्ड कम से कम 8 वर्ण होना चाहिए")
      setIsLoading(false)
      return
    }

    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`,
          data: {
            business_name: businessName || "My Dairy",
          },
        },
      })
      if (error) throw error
      router.push("/auth/sign-up-success")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center p-6 md:p-10 bg-background">
      <div className="w-full max-w-sm">
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-3xl font-bold text-primary">{t("appName", language)}</h1>
            <button
              onClick={() => setLanguage(language === "en" ? "hi" : "en")}
              className="px-3 py-1 bg-secondary text-secondary-foreground rounded-lg text-sm font-medium hover:opacity-90"
            >
              {language === "en" ? "हिंदी" : "English"}
            </button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">{language === "en" ? "Sign up" : "साइन अप करें"}</CardTitle>
              <CardDescription>
                {language === "en"
                  ? "Create a new account to manage your dairy operations"
                  : "अपने डेयरी संचालन को प्रबंधित करने के लिए एक नया खाता बनाएं"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSignUp}>
                <div className="flex flex-col gap-6">
                  <div className="grid gap-2">
                    <Label htmlFor="business">{language === "en" ? "Business Name" : "व्यवसाय का नाम"}</Label>
                    <Input
                      id="business"
                      type="text"
                      placeholder={language === "en" ? "My Dairy Farm" : "मेरी डेयरी"}
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">{language === "en" ? "Email" : "ईमेल"}</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="dairy@example.com"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="password">{language === "en" ? "Password" : "पासवर्ड"}</Label>
                    <Input
                      id="password"
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      disabled={isLoading}
                    />
                    <p className="text-xs text-muted-foreground">
                      {language === "en" ? "At least 8 characters" : "कम से कम 8 वर्ण"}
                    </p>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="repeat-password">
                      {language === "en" ? "Confirm Password" : "पासवर्ड की पुष्टि करें"}
                    </Label>
                    <Input
                      id="repeat-password"
                      type="password"
                      required
                      value={repeatPassword}
                      onChange={(e) => setRepeatPassword(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                  {error && <p className="text-sm text-red-500">{error}</p>}
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading
                      ? language === "en"
                        ? "Creating account..."
                        : "खाता बनाया जा रहा है..."
                      : language === "en"
                        ? "Sign up"
                        : "साइन अप करें"}
                  </Button>
                </div>
                <div className="mt-4 text-center text-sm">
                  {language === "en" ? "Already have an account? " : "पहले से खाता है? "}
                  <Link href="/auth/login" className="underline underline-offset-4 text-primary">
                    {language === "en" ? "Login" : "लॉगिन करें"}
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
